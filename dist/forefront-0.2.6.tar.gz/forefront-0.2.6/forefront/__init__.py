from forefront.forefront import Forefront, predict
